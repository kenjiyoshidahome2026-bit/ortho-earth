import { isObject } from "../modules/utility.js";
import { geoOrthographic, geoMercator, geoEquirectangular } from "../modules/projections.js";

export function preview(self, canvas, props = {}) {
	if (!self.length) return null;
	if (isObject(canvas)) { props = canvas; canvas = null; }
	const dpr = props.dpr || 1;
	const ownCanvas = !canvas;
	const size = props.size || 512;
	const width  = canvas ? canvas.width  / dpr : size;
	const height = canvas ? canvas.height / dpr : size;

	const projection = props.projection || "";
	const proj = projection.match(/orthographic/i) ? geoOrthographic() : projection.match(/mercator/i) ? geoMercator() : geoEquirectangular();
	let bbox = props.bbox || self.bbox;
	// antimeridian-split datasets can have bbox spanning ~360° even when features don't individually
	// cross the antimeridian (e.g. western Alaska polygons at -180° + Near Islands at +173°E).
	// Fix: 3D-vector centroid of small-span features → re-wrap all bbox coords relative to that
	// centroid longitude so the tight geographic extent is computed in a consistent frame.
	if (!props.bbox && bbox[2] - bbox[0] > 180) {
		const d2r = Math.PI / 180;
		let sx = 0, sy = 0, sz = 0, nc = 0;
		self.forEach(n => {
			const b = self.getBbox(n);
			if (b[2] - b[0] > 180) return;
			const lng = (b[0] + b[2]) / 2, lat = (b[1] + b[3]) / 2;
			sx += Math.cos(lat * d2r) * Math.cos(lng * d2r);
			sy += Math.cos(lat * d2r) * Math.sin(lng * d2r);
			sz += Math.sin(lat * d2r);
			nc++;
		});
		if (nc > 0) {
			const norm = Math.sqrt(sx * sx + sy * sy + sz * sz);
			const cLng = norm > 0.01 ? Math.atan2(sy, sx) / d2r : 0;
			let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
			self.forEach(n => {
				const b = self.getBbox(n);
				if (b[2] - b[0] > 180) return;
				let bx0 = b[0], bx1 = b[2];
				const bc = (bx0 + bx1) / 2;
				if (bc - cLng > 180) { bx0 -= 360; bx1 -= 360; }
				else if (cLng - bc > 180) { bx0 += 360; bx1 += 360; }
				if (bx0 < x0) x0 = bx0;
				if (b[1] < y0) y0 = b[1];
				if (bx1 > x1) x1 = bx1;
				if (b[3] > y1) y1 = b[3];
			});
			if (x0 < Infinity) {
				// Preserve lonSpan but shift the center to the 3D centroid cLng.
				const shift = cLng - (x0 + x1) / 2;
				bbox = [x0 + shift, y0, x1 + shift, y1];
			}
		}
	}
	const pbf = self.pbf, e = self.e;
	const radius = props.radius || 1.5;

	const cx = (bbox[0] + bbox[2]) / 2;
	const cy = (bbox[1] + bbox[3]) / 2;
	const lonSpan = Math.max(bbox[2] - bbox[0], 1e-3);
	const latSpan = Math.max(bbox[3] - bbox[1], 1e-3);
	const scale = Math.min(width / lonSpan, height / latSpan) * (180 / Math.PI) * 0.9;
	proj.rotate([-cx, -cy, 0]).scale(scale).translate([width / 2, height / 2]);
	if (props.scale) proj.scale(props.scale);

	const offcanvas = ownCanvas ? new OffscreenCanvas(width * dpr, height * dpr) : canvas;
	const ctx = offcanvas.getContext("2d");
	if (dpr !== 1) ctx.scale(dpr, dpr);

	if (props.background) { ctx.fillStyle = props.background; ctx.fillRect(0, 0, width, height); }
	ctx.lineWidth = props.lineWidth || 1 / dpr;
	ctx.fillStyle = props.fill || "#ccc";
	ctx.strokeStyle = props.stroke || "#000";

	const out = b => (bbox[0] > b[2] || bbox[1] > b[3] || bbox[2] < b[0] || bbox[3] < b[1]);
	const minDist = props.minDist || 1;
	const minDist2 = minDist * minDist;

	self.forEach((n, map) => {
		if (out(self.getBbox(n))) return;
		ctx.beginPath();

		const drawCoords = (pos, type) => {
			pbf.pos = pos;
			let lens = [];

			pbf.readMessage(tag => {
				if (tag === 9) pbf.readPackedVarint(lens);
				else if (tag === 10) {
					const end = pbf.readVarint() + pbf.pos;
					let p = [0, 0];
					const readNext = () => {
						p[0] += pbf.readSVarint();
						p[1] += pbf.readSVarint();
						return proj([p[0] / e, p[1] / e]);
					};

					if (type === 0) {
						const pt = readNext();
						if (pt) { ctx.moveTo(pt[0] + radius, pt[1]); ctx.arc(pt[0], pt[1], radius, 0, Math.PI * 2); }
					} else if (type === 1) {
						while (pbf.pos < end) {
							const pt = readNext();
							if (pt) { ctx.moveTo(pt[0] + radius, pt[1]); ctx.arc(pt[0], pt[1], radius, 0, Math.PI * 2); }
						}
					} else if (type === 2) {
						let i = 0;
						while (pbf.pos < end) {
							const pt = readNext();
							if (pt) ctx[i++ ? "lineTo" : "moveTo"](...pt);
						}
					} else if (type === 3) {
						// lens = [nPts_sub0, nPts_sub1, ...] (flat, one entry per sub-line)
						// each sub-line is diff-encoded from [0,0] independently
						for (let si = 0; si < lens.length; si++) {
							p[0] = 0; p[1] = 0;
							let i = 0;
							for (let pi = 0; pi < lens[si]; pi++) {
								const pt = readNext();
								if (pt) ctx[i++ ? "lineTo" : "moveTo"](...pt);
							}
						}
					} else {
						let pos = 0;
						const drawRing = (n) => {
							let pRing = [0, 0], lx, ly, i = 0;
							while (n-- > 0) {
								pRing[0] += pbf.readSVarint();
								pRing[1] += pbf.readSVarint();
								const pt = proj([pRing[0] / e, pRing[1] / e]);
								if (!pt) continue;
								if (i === 0) { ctx.moveTo(...pt); lx = pt[0]; ly = pt[1]; i++; continue; }
								const dx = pt[0] - lx, dy = pt[1] - ly;
								if (dx*dx + dy*dy < minDist2 && n > 0) continue;
								ctx.lineTo(...pt); lx = pt[0]; ly = pt[1];
							}
							ctx.closePath();
						};
						if (type === 4) lens.forEach(drawRing);
						else {
							for (let i = 0; i < lens[0]; i++) {
								const nRings = lens[++pos];
								for (let j = 0; j < nRings; j++) drawRing(lens[++pos]);
							}
						}
					}
				}
			});
		};

		if (map[2] === 6) map[3].forEach((t, i) => drawCoords(t, map[4][i]));
		else drawCoords(map[1], map[2]);

		if (map[2] < 2 || map[2] > 3) ctx.fill();
		ctx.stroke();
	});

	return ownCanvas ? offcanvas.transferToImageBitmap() : canvas;
}
